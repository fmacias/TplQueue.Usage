using Microsoft.Extensions.DependencyInjection;
using System;
using TplQueue.Sample.Etl.Contracts;
using TplQueue.Sample.Etl.Handlers;
using TplQueue.Sample.Etl.Runtime;

namespace TplQueue.Sample.Etl.Composition
{
    /// <summary>Registers the fixed, backend-owned sample ETL workflow.</summary>
    public static class SampleEtlServiceCollectionExtensions
    {
        public static IServiceCollection AddSampleEtlWorkflow(this IServiceCollection services)
        {
            if (services == null) throw new ArgumentNullException(nameof(services));

            services.AddSingleton<EtlExecutionDataStore>();
            services.AddSingleton<IngestMeasurementsHandler>();
            services.AddSingleton<TransformMeasurementsHandler>();
            services.AddSingleton<LoadMeasurementsHandler>();
            services.AddSingleton<EtlQueueRuntime>();
            services.AddSingleton<IEtlWorkflow, EtlWorkflow>();
            return services;
        }
    }
}
