using System;
using System.Collections.Generic;
using System.Threading;
using Fmacias.TplQueue.Contracts;
using Fmacias.TplQueue.Defaults;
using Fmacias.TplQueue.Extensions;
using TplQueue.Sample.Etl.Contracts;
using TplQueue.Sample.Etl.Contracts.Dto;
using TplQueue.Sample.Etl.Handlers;
using TplQueue.Sample.Etl.Payloads;
using TplQueue.Sample.Etl.Runtime;

namespace TplQueue.Sample.Etl
{
    internal sealed class EtlWorkflow : IEtlWorkflow, IDisposable
    {
        private readonly IDataJobFactory _dataJobFactory;
        private readonly IngestMeasurementsHandler _ingestHandler;
        private readonly TransformMeasurementsHandler _transformHandler;
        private readonly LoadMeasurementsHandler _loadHandler;
        private readonly EtlQueueRuntime _runtime;
        private bool _disposed;

        public EtlWorkflow(
            IDataJobFactory dataJobFactory,
            IngestMeasurementsHandler ingestHandler,
            TransformMeasurementsHandler transformHandler,
            LoadMeasurementsHandler loadHandler,
            EtlQueueRuntime runtime)
        {
            _dataJobFactory = dataJobFactory ?? throw new ArgumentNullException(nameof(dataJobFactory));
            _ingestHandler = ingestHandler ?? throw new ArgumentNullException(nameof(ingestHandler));
            _transformHandler = transformHandler ?? throw new ArgumentNullException(nameof(transformHandler));
            _loadHandler = loadHandler ?? throw new ArgumentNullException(nameof(loadHandler));
            _runtime = runtime ?? throw new ArgumentNullException(nameof(runtime));
        }

        public Guid EnqueueMeasurements(
            AvailableQueue availableQueue,
            IReadOnlyList<LegacyMeasurement> legacyMeasurements, 
            CancellationToken cancellationToken)
        {
            ThrowIfDisposed();

            if (legacyMeasurements == null) 
                throw new ArgumentNullException(nameof(legacyMeasurements));
            
            if (legacyMeasurements.Count == 0)
            {
                throw new ArgumentException(
                    "At least one legacy measurement is required.",
                    nameof(legacyMeasurements));
            }
            var root = CreateDataJobRoot(legacyMeasurements);
            _runtime.Enqueue(availableQueue, root, cancellationToken);
            return root.Id;
        }

        public void Dispose()
        {
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }
            _disposed = true;

            if (disposing)
            {
                _runtime.Dispose();
            }
        }

        private IDataJobRoot CreateDataJobRoot(IReadOnlyList<LegacyMeasurement> legacyMeasurements)
        {
            var etlOperationId = Guid.NewGuid();
            var ingestPayload = IngestMeasurementsPayload.Create(
                legacyMeasurements,
                etlOperationId);

            var ingest = _dataJobFactory.DataJob(
                ingestPayload,
                _ingestHandler,
                "Ingest measurements");

            var transform = _dataJobFactory.DataJob(
                TransformMeasurementsPayload.Create(
                    ingestPayload.CollectionTime,
                    etlOperationId),
                _transformHandler,
                "Transform measurements");

            var load = _dataJobFactory.DataJobRoot(
                etlOperationId,
                LoadMeasurementsPayload.Create(
                    ingestPayload.CollectionTime,
                    etlOperationId),
                _loadHandler,
                "Load measurement summary",
                () => NoRetryPolicy.Create());

            return ingest.Then(transform).Then(load);
        }

        private void ThrowIfDisposed()
        {
            if (_disposed)
            {
                throw new ObjectDisposedException(nameof(EtlWorkflow));
            }
        }

        public bool Cancel(Guid rootJobId)
        {
            return _runtime.Cancel(rootJobId);
        }

        ~EtlWorkflow()
        {
            Dispose(false);
        }
    }
}
