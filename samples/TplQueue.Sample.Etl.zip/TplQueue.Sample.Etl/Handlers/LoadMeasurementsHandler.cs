using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using TplQueue.Sample.Etl.Payloads;
using TplQueue.Sample.Etl.Runtime;

namespace TplQueue.Sample.Etl.Handlers
{
    internal sealed class LoadMeasurementsHandler : EtlPayloadHandler<LoadMeasurementsPayload>
    {
        private readonly EtlExecutionDataStore _store;
        private readonly ILogger<LoadMeasurementsHandler> _logger;

        public LoadMeasurementsHandler(
            EtlExecutionDataStore store,
            ILogger<LoadMeasurementsHandler> logger)
        {
            _store = store ?? throw new ArgumentNullException(nameof(store));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        protected override Task HandleAsync(
            LoadMeasurementsPayload payload,
            CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();

            if (!_store.TryGetSummary(payload.EtlOperationId, out var summary))
            {
                throw new InvalidOperationException(
                    "Load cannot run because Transform did not produce a summary.");
            }

            _logger.LogInformation("Loaded measurement summary: {Summary}.", summary);
            return Task.CompletedTask;
        }
    }
}
