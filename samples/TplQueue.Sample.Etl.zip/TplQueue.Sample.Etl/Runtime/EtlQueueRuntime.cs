using Fmacias.TplQueue.Contracts;
using System;
using System.Collections.Concurrent;
using System.Threading;
using TplQueue.Sample.Etl.Contracts;

namespace TplQueue.Sample.Etl.Runtime
{
    internal sealed class EtlQueueRuntime : IDisposable
    {
        private readonly IFifoQ _fifoQ;
        private readonly IParallelQ _parallelQ;
        private readonly ICacheQ _cacheQ;
        private bool _disposed;
        private readonly ConcurrentDictionary<Guid, CancellationTokenSource> _cancellations = 
            new ConcurrentDictionary<Guid, CancellationTokenSource>();

        public EtlQueueRuntime(IFifoQ fifoQ, IParallelQ parallelQ, ICacheQ cacheQ)
        {
            if (fifoQ == null) throw new ArgumentNullException(nameof(fifoQ));
            if (parallelQ == null) throw new ArgumentNullException(nameof(parallelQ));
            if (cacheQ == null) throw new ArgumentNullException(nameof(cacheQ));

            _fifoQ = fifoQ;
            _parallelQ = parallelQ;
            _cacheQ = cacheQ;
        }

        public void Enqueue(AvailableQueue avalQueue, IDataJobRoot root, 
            CancellationToken cancellationToken)
        {
            ThrowIfDisposed();

            if (root == null) throw new ArgumentNullException(nameof(root));

            cancellationToken.ThrowIfCancellationRequested();

            var cancelationTokenSource = RootJobCancelationSource(root, cancellationToken);
            var ctToken = cancelationTokenSource.Token;

            switch (avalQueue)
            {
                case AvailableQueue.FIFO:
                    _fifoQ.Enqueue(root, ctToken);
                    break;
                case AvailableQueue.Parallel:
                    _parallelQ.Enqueue(root, ctToken);
                    break;
                case AvailableQueue.Cache:
                    _cacheQ.Enqueue(root, ctToken);
                    break;
                default:
                    throw new InvalidOperationException($"Queue type ({avalQueue}) not recognized");
            }
        }

        private CancellationTokenSource RootJobCancelationSource(IDataJobRoot root, CancellationToken cancellationToken)
        {
            var cancelationTokenSource = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);

            if (!_cancellations.TryAdd(root.Id, cancelationTokenSource))
            {
                cancelationTokenSource.Dispose();
                throw new InvalidOperationException($"Cancellation state for root job '{root.Id}' already exists.");
            }
            return cancelationTokenSource;
        }

        public bool Cancel(Guid rootJobId)
        {
            ThrowIfDisposed();

            if (!_cancellations.TryGetValue(rootJobId, out var cancellation))
            {
                return false;
            }

            try
            {
                cancellation.Cancel();
                return true;
            }
            catch (ObjectDisposedException)
            {
                return false;
            }
        }

        public void Dispose()
        {
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed) return;

            if (disposing)
            {
                DisposeRelatedCancellations();
                _fifoQ.Dispose();
                _cacheQ.Dispose();
                _parallelQ.Dispose();
                _disposed = true;
            }
        }

        private void DisposeRelatedCancellations()
        {
            foreach (var rootJobId in _cancellations.Keys)
            {
                if (_cancellations.TryRemove(rootJobId, out var cancellation))
                {
                    try
                    {
                        cancellation?.Cancel();
                    }
                    catch (ObjectDisposedException)
                    {
                    }
                    cancellation?.Dispose();
                }
            }
        }

        private void ThrowIfDisposed()
        {
            if (_disposed)
            {
                throw new ObjectDisposedException(nameof(EtlQueueRuntime));
            }
        }
        ~EtlQueueRuntime()
        {
            Dispose(false);
        }
    }
}
