using Fmacias.TplQueue.Core;
using Fmacias.TplQueue.Microsoft.DependencyInjection;
using TplQueue.Sample.BlazorSignalR.Components;
using TplQueue.Sample.BlazorSignalR.Composition;
using TplQueue.Sample.BlazorSignalR.Presentation.Etl;
using TplQueue.Sample.Etl.Composition;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();
    
// Add TplQueue services to the container
builder.Services.AddTplQueue(builder.Configuration, CoreApi.Create());
builder.Services.AddSampleEtlWorkflow();
builder.Services.AddMeasurementEtlConsumer();

var app = builder.Build();

app.Services.RegisterSampleEtlPayloadHandlers();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();

app.UseStaticFiles();
app.UseAntiforgery();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

var etlQueueObserver = app.Services.GetRequiredService<EtlQueueObserver>();

app.Run();
