using Fmacias.TplQueue.Contracts;

namespace TplQueue.Sample.BlazorSignalR.Presentation.Etl;

/// <summary>Forwards events from the dedicated ETL queue to the ETL workflow.</summary>
internal sealed class EtlQueueObserver : IObserver<IJobEvent>
{
    private readonly IObserverDispatcher _dispatcher;
    private readonly ILogger _logger;

    public EtlQueueObserver(IObserverDispatcher dispatcher, ILogger logger)
    {
        _dispatcher = dispatcher ?? throw new ArgumentNullException(nameof(dispatcher));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public void OnCompleted()
    {
    }

    public void OnError(Exception error)
    {
        _logger.LogError(error, "The sample ETL queue observer stopped unexpectedly.");
    }

    public void OnNext(IJobEvent value)
    {
        if (value == null) throw new ArgumentNullException(nameof(value));

        try
        {
            throw new NotImplementedException("observer implementation not valid. IObserverDispatcher can not be used as standard adapter component");
        }
        catch (Exception exception)
        {
            _logger.LogError(exception, "The sample ETL job-event consumer failed.");
        }
    }
}
