using Fmacias.TplQueue.Contracts;
using TplQueue.Sample.BlazorSignalR.Application;
using TplQueue.Sample.Etl.Contracts;

namespace TplQueue.Sample.BlazorSignalR.Presentation.Etl;

internal sealed class EtlWorkflowPresentationService : IEtlWorkflowPresentationService
{
    private readonly ILegacyMeasurementScenario _scenario;
    private readonly IEtlWorkflow _workflow;
    private readonly object _sync = new();
    private readonly List<IJobEvent> _events = new();
    private Guid? _rootJobId;

    public EtlWorkflowPresentationService(
        ILegacyMeasurementScenario scenario,
        IEtlWorkflow workflow)
    {
        _scenario = scenario ?? throw new ArgumentNullException(nameof(scenario));
        _workflow = workflow ?? throw new ArgumentNullException(nameof(workflow));
    }

    public event EventHandler? Changed;
    public IReadOnlyList<IJobEvent> Events
    {
        get
        {
            lock (_sync)
            {
                return _events.ToArray();
            }
        }
    }

    public Guid? RootJobId
    {
        get
        {
            lock (_sync)
            {
                return _rootJobId;
            }
        }
    }

    public void Start(AvailableQueue availableQueue, CancellationToken cancellationToken)
    {
        lock (_sync)
        {
            _events.Clear();
            _rootJobId = null;
        }
        Changed?.Invoke(this, EventArgs.Empty);

        var rootJobId = _scenario.Run(availableQueue, cancellationToken);
        
        lock (_sync)
        {
            _rootJobId = rootJobId;
        }
        Changed?.Invoke(this, EventArgs.Empty);
    }

    public bool CancelCurrent()
    {
        Guid? rootJobId;
        lock (_sync)
        {
            rootJobId = _rootJobId;
        }

        return rootJobId.HasValue && _workflow.Cancel(rootJobId.Value);
    }
}
