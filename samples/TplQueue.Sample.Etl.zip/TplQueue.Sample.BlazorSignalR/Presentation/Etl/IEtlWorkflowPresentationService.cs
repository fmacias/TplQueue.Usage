using Fmacias.TplQueue.Contracts;
using TplQueue.Sample.Etl.Contracts;

namespace TplQueue.Sample.BlazorSignalR.Presentation.Etl;

internal interface IEtlWorkflowPresentationService
{
    event EventHandler? Changed;
    IReadOnlyList<IJobEvent> Events { get; }
    Guid? RootJobId { get; }
    void Start(AvailableQueue availableQueue, CancellationToken cancellationToken);
    bool CancelCurrent();
}
