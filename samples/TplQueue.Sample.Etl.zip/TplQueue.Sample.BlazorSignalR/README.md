# TplQueue Blazor observable ETL sample

This .NET 8 Blazor Interactive Server application is the consumer and host of
the reusable `TplQueue.Sample.Etl` backend module. It demonstrates how an
application submits its own legacy domain data through a shared input contract
while backend code owns the immutable payload snapshots, handlers, graph, FIFO
queue, retry policy, and observer-driven event stream.

The sample uses source project references to the sibling Adapter DI and Core
projects while the package versions are being advanced.

The backend-owned composition and invocation flow is documented in
[`AddQueue.puml`](AddQueue.puml).

## Run

```powershell
dotnet run --project .\TplQueue.Sample.BlazorSignalR.csproj
```

Open `/` to use the observable ETL dashboard. Blazor Interactive Server invokes
the backend scenario through dependency injection and renders observer changes
through its existing SignalR circuit.

The Blazor consumer owns `EtlQueueObserver`, resolves it together with the
dedicated ETL queue event source, and calls
`eventSource.JobEvents.Subscribe(observer)` in `Program.cs`, immediately before
`app.Run()`. `EtlQueueRuntime` neither creates the observer nor performs the
subscription. The `using` declaration retains the returned subscription until
`app.Run()` returns during application finalization. Observer lifetime remains
independent from queue dispatch.

## Workflow boundary

```text
Consumer LegacyMeasurement objects
  -> LegacyMeasurementScenario
  -> IReadOnlyList<ILegacyMeasurement>
  -> shared IEtlWorkflow facade
  -> immutable Ingest payload measurement snapshots
  -> predefined Ingest -> Transform -> Load graph
  -> backend-owned IFifoQ
  -> dedicated observer forwarding raw IJobEvent metadata
  -> Blazor Interactive Server presentation
```

The browser does not select queues, retry policies, payload handlers, or graph
topology. The ETL module executes real `IDataJob` and `IDataJobRoot` instances
and exposes the immutable metadata snapshots already carried by `IJobEvent`.
Payload objects are not retained or transported by observer events.

The dashboard's button invokes one semantic backend scenario. After the host
service provider is built, the ETL module registers its three payload handlers.
The dedicated queue remains lazy and is created only when the host resolves the
ETL queue event source. Payload construction and graph topology also remain in
backend composition.

The shared module is host-independent and targets `netstandard2.0`. The
workflow accepts the consumer-owned `IReadOnlyList<ILegacyMeasurement>` and
copies its scalar values into immutable, serializer-compatible snapshots owned
by the Ingest payload. A small internal data store passes normalized values and
the summary between handlers; it does not duplicate lifecycle state from
`IJobEvent` or create presentation snapshots.

This is intentionally a single-operation demonstration. The singleton queue
and observer live for the application lifetime, but the sample does not
correlate one global event stream across concurrent Blazor circuits. A
multi-user application should add a correlation-aware status projection before
presenting events per circuit.

The current runtime intentionally uses `IFifoQ`. `ICacheQ` integration remains
a follow-up because the current background leasing path accepted dehydration
but did not dispatch the hydrated sample graph. The sample does not claim
distributed durability. `EtlPayloadTypeResolver` is retained for that future
controlled cache-hydration path and is not used by the current FIFO runtime.
