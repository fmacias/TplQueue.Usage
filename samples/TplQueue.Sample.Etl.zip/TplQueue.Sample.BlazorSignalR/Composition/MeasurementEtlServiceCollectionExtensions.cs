using TplQueue.Sample.BlazorSignalR.Application;
using TplQueue.Sample.BlazorSignalR.Presentation.Etl;

namespace TplQueue.Sample.BlazorSignalR.Composition;

internal static class MeasurementEtlServiceCollectionExtensions
{
    public static IServiceCollection AddMeasurementEtlConsumer(this IServiceCollection services)
    {
        if (services == null) throw new ArgumentNullException(nameof(services));

        services.AddSingleton<ILegacyMeasurementCollector, LegacyMeasurementCollector>();
        services.AddSingleton<ILegacyMeasurementScenario, LegacyMeasurementScenario>();
        services.AddSingleton<EtlQueueObserver>();
        services.AddScoped<IEtlWorkflowPresentationService, EtlWorkflowPresentationService>();
        return services;
    }
}
